<div class="comment-section">
    <h6 data-scroll-reveal="enter from the bottom after 0.3s">
        <span class="commenthr bottomline"><span class="txt-red">Our</span> Valuable Clients</span>
    </h6>
    <br/><br/>
    <div>
       
        <div class="row text-center">
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                <div class="team-box effect-helix in" data-effect="helix" style="transition: all 0.7s ease-in-out 0s;">
                    <img class="aligncenter" src="<?php base_url(); ?>assets/img/client/bestech-logo.jpg" alt="">                      
                </div> 
            </div> 
            
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                <div class="team-box effect-helix in" data-effect="helix" style="transition: all 0.7s ease-in-out 0s;">
                    <img class="aligncenter" src="<?php base_url(); ?>assets/img/client/exotica-logo.jpg" alt="">                       
                </div> 
            </div>
            
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                <div class="team-box effect-helix in" data-effect="helix" style="transition: all 0.7s ease-in-out 0s;">
                    <img class="aligncenter" src="<?php base_url(); ?>assets/img/client/hero-homes-logo.jpg" alt="">                       
                </div> 
            </div>
            
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                <div class="team-box effect-helix in" data-effect="helix" style="transition: all 0.7s ease-in-out 0s;">
                    <img class="aligncenter" src="<?php base_url(); ?>assets/img/client/radisson-logo.jpg" alt="">                      
                </div> 
            </div>
        </div> 

        <div class="row text-center">
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                <div class="team-box effect-helix in" data-effect="helix" style="transition: all 0.7s ease-in-out 0s;">
                    <img class="aligncenter" src="<?php base_url(); ?>assets/img/client/rof-logo.jpg" alt="">                       
                </div> 
            </div> 
            
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                <div class="team-box effect-helix in" data-effect="helix" style="transition: all 0.7s ease-in-out 0s;">
                    <img class="aligncenter" src="<?php base_url(); ?>assets/img/client/vvip-logo.jpg" alt="">                     
                </div> 
            </div>
            
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                <div class="team-box effect-helix in" data-effect="helix" style="transition: all 0.7s ease-in-out 0s;">
                    <img class="aligncenter" src="demos/team1.png" alt="">
                                           
                </div> 
            </div>
            
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                <div class="team-box effect-helix in" data-effect="helix" style="transition: all 0.7s ease-in-out 0s;">
                    <img class="aligncenter" src="demos/team1.png" alt="">
                                       
                </div> 
            </div>
        </div>

    </div>
    <div class="clearfix"></div>                                                    
</div>
