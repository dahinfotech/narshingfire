<div class="comment-section">
    <h6 data-scroll-reveal="enter from the bottom after 0.3s">
        <span class="commenthr bottomline"><span class="txt-red">Fire</span> SUPPRESSION SYSTEM</span>
    </h6>
    <br/>
    <p> A fire suppression system is designed in such a way so that it can easily stop the fire from spreading further. The system gets its name as it tries to hold back the fire and the damage which it might cause eventually.</p>
    <div class="clearfix"></div>
    <div class="media row">
        <div class="col-sm-6">
            <div class="brand-content wow fadeIn animated" style="visibility: visible; -webkit-animation: fadeIn 700ms 300ms;">
                <i class="fa fa-lightbulb-o fa-4x pull-left"></i>
                <div class="media-body">                            
                    <h4>Pre Engineered Systems</h4>
                    <p> Fire suppression can be of great help. it can promptly notify organizations about fire and smoke conditions in the building. Once informed, organizations can take the necessary steps and mitigate the damage.</p>
                </div>
            </div>                      
        </div>
        <div class="col-sm-6">
            <div class="brand-content wow fadeIn animated" style="visibility: visible; -webkit-animation: fadeIn 700ms 400ms;">
                <i class="fa fa-laptop fa-4x pull-left"></i>
                <div class="media-body">                            
                    <h4>Kitchen Suppression System</h4>
                    <p> Fire suppression can be of great help. it can promptly notify organizations about fire and smoke conditions in the building. Once informed, organizations can take the necessary steps and mitigate the damage.</p>
                </div>
            </div>                      
        </div>        
    </div>

    <div class="media row">
        <div class="col-sm-6">
            <div class="brand-content wow fadeIn animated" style="visibility: visible; -webkit-animation: fadeIn 700ms 300ms;">
                <i class="fa fa-lightbulb-o fa-4x pull-left"></i>
                <div class="media-body">                            
                    <h4>Total Flooding System</h4>
                    <p> Fire suppression can be of great help. it can promptly notify organizations about fire and smoke conditions in the building. Once informed, organizations can take the necessary steps and mitigate the damage.</p>
                </div>
            </div>                      
        </div>
        <div class="col-sm-6">
            <div class="brand-content wow fadeIn animated" style="visibility: visible; -webkit-animation: fadeIn 700ms 400ms;">
                <i class="fa fa-laptop fa-4x pull-left"></i>
                <div class="media-body">                            
                    <h4>Fire Trace System</h4>
                    <p> Fire suppression can be of great help. it can promptly notify organizations about fire and smoke conditions in the building. Once informed, organizations can take the necessary steps and mitigate the damage.</p>
                </div>
            </div>                      
        </div>        
    </div>
    <br/>
    <div class="clearfix"></div>
    <div class="row">A fire suppression system usually extinguishes the flames through heat absorption. In order to minimize the damage and loses from fire, a fire suppression system might use a gaseous agent or dry chemicals or wet agent.
	</div>
</div>

<div class="sticky-contact">
  <a href="javascript:void(0)" class="btn btn-default quote-btn" onclick="productEnquiry('FIRE SUPPRESSION SYSTEM');" >Request A Quote</a>
</div>

<?php $this->load->view('Elements/Common/request_a_quote'); ?>