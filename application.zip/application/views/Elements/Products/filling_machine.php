<div class="comment-section">
    <h6 data-scroll-reveal="enter from the bottom after 0.3s">
        <span class="commenthr bottomline"><span class="txt-red">Extinguisher</span> Filling Machine</span>
    </h6>
    <br/>
    <p>An extinguisher filling machine can easily fill or refill a fire extinguisher system, with any kind of fire extinguishing agent.  it can be foam, water, powder, or gas.</p>

    <div class="row text-center">
        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <div data-scroll-reveal="enter from the bottom after 0.4s" class="about-box">
                <div class="about-border">
                	<img src="<?php echo base_url(); ?>assets/img/nitrogen-filling-machine.png" />
                </div>
                <h4>Nitrogen Filling Machine</h4>
                
            </div>
        </div><!-- end column -->

        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <div data-scroll-reveal="enter from the bottom after 0.5s" class="about-box">
                    <div class="about-border"> 
                    	<img src="<?php echo base_url(); ?>assets/img/powder-filling-machine.png" />
                    </div>
                    <h4>Powder Filling Machine</h4>
                    
            </div>
        </div>
    </div>
    <div class="clearfix"></div>
    <div class="row"></div>

</div>