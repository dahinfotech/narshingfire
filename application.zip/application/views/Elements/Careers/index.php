<div class="comment-section">
    <h6 data-scroll-reveal="enter from the bottom after 0.3s">
        <span class="commenthr bottomline"><span class="txt-red">Career</span> With Narshing Fire</span>
    </h6>
    <br/><br/>
    <div>
        <p><h3>We’re looking for talented Sales and Marketing Staff, Please share your resume at- <i>narshingfire@gmail.com</i></h3></p>
        <br/><
        <p><h4>Call us today at +91 971 804 0323 or Email us at narshingfire@gmail.com</h4></p>
    </div>
    <div class="clearfix"></div>                                                    
</div>
