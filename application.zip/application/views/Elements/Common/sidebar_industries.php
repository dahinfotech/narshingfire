<div class="sidebar-widget">
    <h5>Our <span class="txt-red">Industries</span></h5>
    <ul class="tags-list" data-scroll-reveal="enter from the bottom after 0.5s">
        <li><a href="<?php echo base_url(); ?>Industries">Retail</a></li>
        <li><a href="<?php echo base_url(); ?>Industries">Assisted Living</a></li>
        <li><a href="<?php echo base_url(); ?>Industries">Restaurant</a></li>
        <li><a href="<?php echo base_url(); ?>Industries">Education</a></li>
        <li><a href="<?php echo base_url(); ?>Industries">Property Management</a></li>
        <li><a href="<?php echo base_url(); ?>Industries">Government</a></li>
        <li><a href="<?php echo base_url(); ?>Industries">Multi-Family Property</a></li>
        <li><a href="<?php echo base_url(); ?>Industries">Healthcare</a></li>
        <li><a href="<?php echo base_url(); ?>Industries">Hospitality</a></li>
        <li><a href="<?php echo base_url(); ?>Industries">Industrial</a></li>
    </ul>
</div>