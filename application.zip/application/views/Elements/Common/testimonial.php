<div class="testimonial text-center">
    <h2 class="three" data-scroll-reveal="enter from the bottom after 0.2s">And What<span class="txt-red"> They Say</span></h2>
</div><!-- end title -->

<div id="testimonial" class="owl-carousel owl-theme text-center">
    <div class="testimonial"  data-scroll-reveal="enter from the bottom after 0.3s">
        <p>Excellent service of Narshing fire safety</p>
        <h1> Harish Aggarwal </h1>
    </div>
    <div class="testimonial">
        <p>Very nice service of Narshing fire, expert team</p>
        <h1> Krihna jain </h1>
    </div>
    <div class="testimonial">
        <p>Narshing fire also giving very good service</p>
        <h1> DANIEL Smith </h1>
    </div>
</div><!-- end #testimonial -->

<div class="customNavigation">
    <a class="btn prev"><i class="fa fa-angle-left fa-2x"></i></a>
    <a class="btn next"><i class="fa fa-angle-right fa-2x"></i></a>
</div><!-- end customnav -->