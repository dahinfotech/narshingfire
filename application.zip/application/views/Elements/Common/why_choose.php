<div id="accordion-second" class="clearfix">
                        <div class="accordion" id="accordion2">
                          <div class="accordion-group">
                            <div class="accordion-heading">
                              <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseOne">
                                <em class="fa fa-plus icon-fixed-width"></em>FIRE EXTINGUISHERS
                              </a>
                            </div>
                            <div id="collapseOne" class="accordion-body collapse">
                              <div class="accordion-inner">
                                <div style="width: 30%;float: left;">
                                  <img src="<?php echo base_url(); ?>assets/img/fire-extinguisher.jpg" style="width: 152px;">
                                </div>
                                <div style="width: 69%;float: right;color: #222222;">
                                Mechanical, ABC, Water, Co2,  Foam, Clean Agent, Trolley Mounted, Kitchen Fire Extinguisher, Modular Fire Extinguisher etc.</div>
                              </div>
                              <div style="clear: both;"></div>
                            </div>
                          </div>
                          <div class="accordion-group">
                            <div class="accordion-heading">
                              <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseTwo">
                                <em class="fa fa-plus icon-fixed-width"></em>FIRE HYDRANT PRODUCTS
                              </a>
                            </div>
                            <div id="collapseTwo" class="accordion-body collapse">
                              <div class="accordion-inner">
                                <div style="width: 30%;float: left;">
                                  <img src="<?php echo base_url(); ?>assets/img/product-6.jpeg" style="width: 152px;">
                                </div>
                                <div style="width: 69%;float: right;color: #222222;">
                                  RRL Hose Pipe, Fire Hydrant Valve, Fire Hose Reel, Fire Hose Box,  Branch Nozzle, Sprinklers, Fire Pumps, Fire Fighting System Panel etc.
                                </div>
                              </div>
                              <div style="clear: both;"></div>
                            </div>
                          </div>
                          <div class="accordion-group">
                            <div class="accordion-heading">
                              <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseThree">
                                <em class="fa fa-plus icon-fixed-width"></em>FIRE ALARM EQUIPMENT
                              </a>
                            </div>
                            <div id="collapseThree" class="accordion-body collapse">
                              <div class="accordion-inner">
                                <div style="width: 30%;float: left;">
                                  <img src="<?php echo base_url(); ?>assets/img/product-7.jpeg" style="width: 152px;">
                                </div>
                                <div style="width: 69%;float: right;color: #222222;">
                                Conventional Fire Alarm System, Smoke Detector, MCP, Hooter, Heat Detector, Fire Alarm Panel, Wireless Addressable Fire Alarm System etc.
                              </div>
                              </div>
                              <div style="clear: both;"></div>
                            </div>
                          </div>
                          <div class="accordion-group">
                            <div class="accordion-heading">
                              <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseFour">
                                <em class="fa fa-plus icon-fixed-width"></em>SIGNAGES
                              </a>
                            </div>
                            <div id="collapseFour" class="accordion-body collapse">
                              <div class="accordion-inner">
                                <div style="width: 30%;float: left;">
                                  <img src="<?php echo base_url(); ?>assets/img/single-exit.jpeg" style="width: 152px;">
                                </div>
                                <div style="width: 69%;float: right;color: #222222;">
                                Laser Exit Signages, Fire Exit Signages, Night Glow Signages, Evacuation Plan etc.
                              </div>
                              </div>
                              <div style="clear: both;"></div>
                            </div>
                          </div>                            
                        </div><!-- end accordion -->
                    </div><!-- end accordion first -->