<div class="sidebar-widget">
    <h5>Our <span class="txt-red">Products</span></h5>

    <div class="sidebar-product" >
        <div class="row" style="margin-top: 5px;">
            <div class="col-sm-4">
                <img src="<?php echo base_url(); ?>assets/img/product/dry_extinguisher.jpg" style="width:80px;" alt=""/></div>
            <div class="col-sm-8"><a href="<?php echo base_url(); ?>Products">Dry Extinguisher</a></div>
        </div>

        <div class="row" style="margin-top: 5px;">
            <div class="col-sm-4">
                <img src="<?php echo base_url(); ?>assets/img/product/foam_extinguisher.jpg" style="width:80px;" alt=""/></div>
            <div class="col-sm-8"><a href="<?php echo base_url(); ?>Products">Foam Extinguisher</a></div>
        </div>

        <div class="row" style="margin-top: 5px;">
            <div class="col-sm-4">
                <img src="<?php echo base_url(); ?>assets/img/product/gas_extinguisher.jpg" style="width:80px;" alt=""/></div>
            <div class="col-sm-8"><a href="<?php echo base_url(); ?>Products">Gas Extinguisher</a></div>
        </div>

        <div class="row" style="margin-top: 5px;">
            <div class="col-sm-4">
                <img src="<?php echo base_url(); ?>assets/img/product/portable_extinguisher.jpg" style="width:80px;" alt=""/></div>
            <div class="col-sm-8"><a href="<?php echo base_url(); ?>Products/fillingMachine">Extinguisher Filling</a></div>
        </div>

        <div class="row" style="margin-top: 5px;">
            <div class="col-sm-4">
                <img src="<?php echo base_url(); ?>assets/img/product/water_fire_extinguisher.jpg" style="width:80px;" alt=""/></div>
            <div class="col-sm-8"><a href="<?php echo base_url(); ?>Products/waterSystem">Water Fire Extinguisher</a></div>
        </div>

        <div class="row" style="margin-top: 5px;">
            <div class="col-sm-4">
                <img src="<?php echo base_url(); ?>assets/img/product/hydran_aAccessories.png" style="width:80px;" alt=""/></div>
            <div class="col-sm-8"><a href="<?php echo base_url(); ?>Products">Hydran Accessories</a></div>
        </div>

        <div class="row" style="margin-top: 5px;">
            <div class="col-sm-4">
                <img src="<?php echo base_url(); ?>assets/img/product/suppression_system.png" style="width:80px;" alt=""/></div>
            <div class="col-sm-8"><a href="<?php echo base_url(); ?>Products/fireSuppression">Suppression System</a></div>
        </div>

    </div>
</div>