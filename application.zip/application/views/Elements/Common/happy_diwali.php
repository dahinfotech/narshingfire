<div id="myModal" class="modal fade" style="top:11%;">
    <div class="modal-dialog">
        <div class="modal-content">
            <div style="" class="happy-diwali">
                
                    <div class='' style="">
                        <div class="col-sm-3" style="background-color: #7b0b0b;">
                            <img src="<?php echo base_url(); ?>assets/img/logo_round_180.png" style="width:80px;height:50px;"/>
                        </div>
                        <div class="col-sm-9 text-center" style="padding-top: 3%;color: white;background-color: #7b0b0b;height: 50px;">
                        NARSHING FIRE & SAFETY SYSTEMS</div>
                    </div>
            </div>
        </div>
    </div>
</div>