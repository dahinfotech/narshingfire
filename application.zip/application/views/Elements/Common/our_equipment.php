<div class="widget">
	<h3>OUR <span class="txt-red">EQUIPMENTS</span></h3>
    <div id="owl-blog" class="owl-carousel">

        <div class="blog-carousel">
            <div class="entry">
                <img src="<?php echo base_url(); ?>assets/img/product-1.jpeg" alt="" class="img-responsive" style="width: 425px;height: 287px;">
                <div class="magnifier">
                    <div class="buttons">
                        <a class="st" rel="bookmark" href="#"><i class="fa fa-link"></i></a>
                    </div><!-- end buttons -->
                </div><!-- end magnifier -->
            </div><!-- end entry -->
            <div class="blog-carousel-header"></div><!-- end blog-carousel-header -->
        </div><!-- end blog-carousel -->

        <div class="blog-carousel">
            <div class="entry">
                <img src="<?php echo base_url(); ?>assets/img/product-2.jpeg" alt="" class="img-responsive" style="width: 425px;height: 287px;">
                <div class="magnifier">
                    <div class="buttons">
                        <a class="st" rel="bookmark" href="#"><i class="fa fa-link"></i></a>
                    </div><!-- end buttons -->
                </div><!-- end magnifier -->
            </div><!-- end entry -->
            <div class="blog-carousel-header"></div><!-- end blog-carousel-header -->
        </div><!-- end blog-carousel -->

        <div class="blog-carousel">
            <div class="entry">
                <img src="<?php echo base_url(); ?>assets/img/product-3.jpeg" alt="" class="img-responsive" style="width: 425px;height: 287px;">
                <div class="magnifier">
                    <div class="buttons">
                        <a class="st" rel="bookmark" href="#"><i class="fa fa-link"></i></a>
                    </div><!-- end buttons -->
                </div><!-- end magnifier -->
            </div><!-- end entry -->
            <div class="blog-carousel-header"></div><!-- end blog-carousel-header -->
        </div><!-- end blog-carousel -->

        <div class="blog-carousel">
            <div class="entry">
                <img src="<?php echo base_url(); ?>assets/img/product-4.jpeg" alt="" class="img-responsive" style="width: 425px;height: 287px;">
                <div class="magnifier">
                    <div class="buttons">
                        <a class="st" rel="bookmark" href="blog-single-sidebar.html"><i class="fa fa-link"></i></a>
                    </div><!-- end buttons -->
                </div><!-- end magnifier -->                
            </div><!-- end entry -->
            <div class="blog-carousel-header"></div><!-- end blog-carousel-header -->
        </div><!-- end blog-carousel -->

        <div class="blog-carousel">
            <div class="entry">
                <img src="<?php echo base_url(); ?>assets/img/product-5.jpeg" alt="" class="img-responsive" style="width: 425px;height: 287px;">
                <div class="magnifier">
                    <div class="buttons">
                        <a class="st" rel="bookmark" href="#"><i class="fa fa-link"></i></a>
                    </div><!-- end buttons -->
                </div><!-- end magnifier -->
            </div><!-- end entry -->
            <div class="blog-carousel-header"></div><!-- end blog-carousel-header -->
        </div><!-- end blog-carousel -->

        <div class="blog-carousel">
            <div class="entry">
                <img src="<?php echo base_url(); ?>assets/img/product-6.jpeg" alt="" class="img-responsive" style="width: 425px;height: 287px;">
                <div class="magnifier">
                    <div class="buttons">
                        <a class="st" rel="bookmark" href="#"><i class="fa fa-link"></i></a>
                    </div><!-- end buttons -->
                </div><!-- end magnifier -->                
            </div><!-- end entry -->
            <div class="blog-carousel-header"></div><!-- end blog-carousel-header -->
        </div><!-- end blog-carousel -->
          
    </div><!-- end owl-blog -->
</div><!-- end widget -->