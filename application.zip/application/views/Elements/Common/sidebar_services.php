<div class="sidebar-widget">
    <h5>Our <span class="txt-red">Services</span></h5>
    <ul class="category-list sidebar-product" data-scroll-reveal="enter from the bottom after 0.2s">
        <li><a href="<?php echo base_url(); ?>Services">Fire Fighting Equipment</a></li>
        <li><a href="<?php echo base_url(); ?>Services">Fire Alarm Equipment</a></li>
        <li><a href="<?php echo base_url(); ?>Services">Safety Equipment</a></li>
        <li><a href="<?php echo base_url(); ?>Services">Security Equipment</a></li>
        <li><a href="<?php echo base_url(); ?>Services">Backflow Devices</a></li>
        <li><a href="<?php echo base_url(); ?>Services">Distributed Antenna Systems</a></li>
        <li><a href="<?php echo base_url(); ?>Services">Dryer Vent Cleaning</a></li>
        <li><a href="<?php echo base_url(); ?>Services">Gas Station Suppression</a></li>
        <li><a href="<?php echo base_url(); ?>Services">System Monitoring</a></li>
        <li><a href="<?php echo base_url(); ?>Services">Kitchen Exhaust Cleaning</a></li>
        <li><a href="<?php echo base_url(); ?>Services">Passive Fire Protection</a></li>
        <li><a href="<?php echo base_url(); ?>Services">HVAC Air Duct Cleaning</a></li>
        <li><a href="<?php echo base_url(); ?>Services">Inspection and Preventative Maintenance</a></li>
        <li><a href="<?php echo base_url(); ?>Services">Special Hazards</a></li>
        <li><a href="<?php echo base_url(); ?>Services">Fire Sprinklers</a></li>
    </ul>
</div>