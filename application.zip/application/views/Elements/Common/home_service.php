<div class="row">

    <div data-scroll-reveal="enter from the bottom after 0.3s" class="col-lg-2 col-md-2 col-sm-8 col-xs-12">
        <div class="service-box margin-top-0px">            
            <h5>Fire Fighting Equipment</h5>
        </div>
    </div>

    <div data-scroll-reveal="enter from the bottom after 0.6s" class="col-lg-2 col-md-2 col-sm-8 col-xs-12">
        <div class="service-box margin-top-0px" >
            <h5>Fire Alarm Equipment</h5>
        </div>
    </div>

    <div data-scroll-reveal="enter from the bottom after 0.9s" class="col-lg-2 col-md-2 col-sm-8 col-xs-12">
        <div class="service-box margin-top-0px">
            <h5>Safety Equipment</h5>
        </div>
    </div>

    <div data-scroll-reveal="enter from the bottom after 0.9s" class="col-lg-2 col-md-2 col-sm-8 col-xs-12">
        <div class="service-box margin-top-0px" >
            <h5>Security Equipment</h5>
        </div>
    </div>

    <div data-scroll-reveal="enter from the bottom after 0.9s" class="col-lg-2 col-md-2 col-sm-8 col-xs-12">
        <div class="service-box margin-top-0px" >
            <h5>ABC Fire Extinguisher</h5>
        </div>
    </div>

    <div data-scroll-reveal="enter from the bottom after 0.9s" class="col-lg-2 col-md-2 col-sm-8 col-xs-12">
        <div class="service-box margin-top-0px">
            <h5>Co2 Fire Extinguisher</h5>
        </div>
    </div>
</div> <!-- end row 1 -->

<div class="row">
    <div data-scroll-reveal="enter from the bottom after 0.3s" class="col-lg-2 col-md-2 col-sm-8 col-xs-12">
        <div class="service-box margin-top-0px" >            
            <h5>Foam Fire Extinguisher</h5>
        </div>
    </div>

    <div data-scroll-reveal="enter from the bottom after 0.6s" class="col-lg-2 col-md-2 col-sm-8 col-xs-12">
        <div class="service-box margin-top-0px" >
            <h5>Fire Hydrant Valve</h5>
        </div>
    </div>

    <div data-scroll-reveal="enter from the bottom after 0.9s" class="col-lg-2 col-md-2 col-sm-8 col-xs-12">
        <div class="service-box margin-top-0px" >
            <h5>Smoke Detector</h5>
        </div>
    </div>

    <div data-scroll-reveal="enter from the bottom after 0.9s" class="col-lg-2 col-md-2 col-sm-8 col-xs-12">
        <div class="service-box margin-top-0px">
            <h5>Fire Hose Reel</h5>
        </div>
    </div>

    <div data-scroll-reveal="enter from the bottom after 0.9s" class="col-lg-2 col-md-2 col-sm-8 col-xs-12">
        <div class="service-box margin-top-0px">
            <h5>Fire Hose Box</h5>
        </div>
    </div>

    <div data-scroll-reveal="enter from the bottom after 0.9s" class="col-lg-2 col-md-2 col-sm-8 col-xs-12">
        <div class="service-box margin-top-0px">
            <h5>Fire Alarm Panel</h5>
        </div>
    </div>
</div> <!-- end row 2 -->

<div class="row">
    <div data-scroll-reveal="enter from the bottom after 0.3s" class="col-lg-2 col-md-2 col-sm-8 col-xs-12">
        <div class="service-box margin-top-0px">            
            <h5>Safety Signage</h5>
        </div>
    </div>

    <div data-scroll-reveal="enter from the bottom after 0.6s" class="col-lg-2 col-md-2 col-sm-8 col-xs-12">
        <div class="service-box margin-top-0px">
            <h5>Fire Suit</h5>
        </div>
    </div>

    <div data-scroll-reveal="enter from the bottom after 0.9s" class="col-lg-2 col-md-2 col-sm-8 col-xs-12">
        <div class="service-box margin-top-0px">
            <h5>Heat Detector</h5>
        </div>
    </div>

    <div data-scroll-reveal="enter from the bottom after 0.9s" class="col-lg-2 col-md-2 col-sm-8 col-xs-12">
        <div class="service-box margin-top-0px">
            <h5>Agni Fire Alarm Panel</h5>
        </div>
    </div>

    <div data-scroll-reveal="enter from the bottom after 0.9s" class="col-lg-2 col-md-2 col-sm-8 col-xs-12">
        <div class="service-box margin-top-0px">
            <h5>Morley Fire Alarm System</h5>
        </div>
    </div>

    <div data-scroll-reveal="enter from the bottom after 0.9s" class="col-lg-2 col-md-2 col-sm-8 col-xs-12">
        <div class="service-box margin-top-0px">
            <h5>Notifier Fire Alarm System</h5>
        </div>
    </div>
</div> <!-- end row 3 -->

<div class="row">
    <div data-scroll-reveal="enter from the bottom after 0.3s" class="col-lg-2 col-md-2 col-sm-8 col-xs-12">
        <div class="service-box margin-top-0px">            
            <h5>RRL Hose Pipe</h5>
        </div>
    </div>

    <div data-scroll-reveal="enter from the bottom after 0.6s" class="col-lg-2 col-md-2 col-sm-8 col-xs-12">
        <div class="service-box margin-top-0px">
            <h5>Sprinkler</h5>
        </div>
    </div>

    <div data-scroll-reveal="enter from the bottom after 0.9s" class="col-lg-2 col-md-2 col-sm-8 col-xs-12">
        <div class="service-box margin-top-0px">
            <h5>Fire Extinguishing Ball</h5>
        </div>
    </div>

    <div data-scroll-reveal="enter from the bottom after 0.9s" class="col-lg-2 col-md-2 col-sm-8 col-xs-12">
        <div class="service-box margin-top-0px">
            <h5>Fire Extinguishing Cube</h5>
        </div>
    </div>

    <div data-scroll-reveal="enter from the bottom after 0.9s" class="col-lg-2 col-md-2 col-sm-8 col-xs-12">
        <div class="service-box margin-top-0px">
            <h5>Que Manager</h5>
        </div>
    </div>

    <div data-scroll-reveal="enter from the bottom after 0.9s" class="col-lg-2 col-md-2 col-sm-8 col-xs-12">
        <div class="service-box margin-top-0px">
            <h5>CCTV</h5>
        </div>
    </div>
</div> <!-- end row 4 -->

<div class="row">
    <div data-scroll-reveal="enter from the bottom after 0.3s" class="col-lg-2 col-md-2 col-sm-8 col-xs-12">
        <div class="service-box margin-top-0px">            
            <h5>Night Glow Signage</h5>
        </div>
    </div>

    <div data-scroll-reveal="enter from the bottom after 0.6s" class="col-lg-2 col-md-2 col-sm-8 col-xs-12">
        <div class="service-box margin-top-0px">
            <h5>Laser Exit Lights</h5>
        </div>
    </div>

    <div data-scroll-reveal="enter from the bottom after 0.9s" class="col-lg-2 col-md-2 col-sm-8 col-xs-12">
        <div class="service-box margin-top-0px">
            <h5>Trolley Fire Extinguisher</h5>
        </div>
    </div>

    <div data-scroll-reveal="enter from the bottom after 0.9s" class="col-lg-2 col-md-2 col-sm-8 col-xs-12">
        <div class="service-box margin-top-0px">
            <h5>Ceasefire Extinguisher</h5>
        </div>
    </div>

    <div data-scroll-reveal="enter from the bottom after 0.9s" class="col-lg-2 col-md-2 col-sm-8 col-xs-12">
        <div class="service-box margin-top-0px">
            <h5>DCP Fire Extinguisher Wholesalers</h5>
        </div>
    </div>

    <div data-scroll-reveal="enter from the bottom after 0.9s" class="col-lg-2 col-md-2 col-sm-8 col-xs-12">
        <div class="service-box margin-top-0px">
            <h5>ISI marked</h5>
        </div>
    </div>
</div> <!-- end row 5 -->