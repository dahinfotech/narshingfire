<div class="page-content page-container" id="page-content">
    <div class="padding">
        <div class="row container-fluid">
            <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title text-center">Our Clients</h4>
                        <div class="owl-carousel">
                            <div class="item"> <img src="<?php echo base_url(); ?>assets/img/exotica-logo.jpg" alt="image" /> </div>

                            <div class="item"> <img src="<?php echo base_url(); ?>assets/img/hero-homes-logo.jpg" alt="image" /> </div>

                            <div class="item"> <img src="<?php echo base_url(); ?>assets/img/radisson-logo.jpg" alt="image" /> </div>

                            <div class="item"> <img src="<?php echo base_url(); ?>assets/img/bestech-logo.jpg" alt="image" /> </div>

                            <div class="item"> <img src="<?php echo base_url(); ?>assets/img/rof-logo.jpg" alt="image" /> </div>

                            <div class="item"> <img src="<?php echo base_url(); ?>assets/img/vvip-logo.jpg" alt="image" /> </div>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

