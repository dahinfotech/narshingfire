<!-- <div class="brand-promotion">
	<div class="container">
		<div class="media row">
			<div class="col-sm-4">
				<div class="brand-content wow fadeIn animated"  style="visibility: visible; -webkit-animation: fadeIn 700ms 300ms;">
					<i class="fa fa-lightbulb-o fa-4x pull-left"></i>
					<div class="media-body">							
						<h2>Ask Us Anything</h2>
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit Curabitur euismod enim a metus adipiscing aliquam.  </p>
					</div>
				</div>						
			</div>
			<div class="col-sm-4">
				<div class="brand-content wow fadeIn animated" style="visibility: visible; -webkit-animation: fadeIn 700ms 400ms;">
					<i class="fa fa-laptop fa-4x pull-left"></i>
					<div class="media-body">							
						<h2>Brand &amp; Identity</h2>
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit Curabitur euismod enim a metus.</p>
					</div>
				</div>						
			</div>
			<div class="col-sm-4">
				<div class="brand-content wow fadeIn animated"  style="visibility: visible; -webkit-animation: fadeIn 700ms 500ms;">
				<i class="fa fa-headphones fa-4x pull-left"></i>
					<div class="media-body">							
						<h2>Full Support</h2>
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit Curabitur euismod enim a metus adipiscing aliquam.</p>
					</div>
				</div>						
			</div>
		</div>
	</div>
</div> -->


<section id="home" class="sliderwrapper clearfix">
	
       <div class="tp-banner-container">
            <div class="tp-banner">
                <ul>
       			  <li data-transition="fade" data-slotamount="7" data-masterspeed="1500" >
                        <!-- MAIN IMAGE -->
                        <img src="<?php echo base_url(); ?>assets/demos/slider1.jpeg"  alt="slidebg1"  data-bgfit="cover" data-bgposition="center center" data-bgrepeat="no-repeat">
        				<div class="tp-dottedoverlay twoxtwo"></div>
 
                        <!-- LAYER NR. 3 -->
                         <div class="tp-caption rev-video  customin customout start"
                            data-x="center"
                            data-hoffset="0"
                            data-y="140"
                            data-customin="x:0;y:0;z:0;rotationX:90;rotationY:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:200;transformOrigin:50% 0%;"
                            data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                            data-speed="1000"
                            data-start="500"
                            data-easing="Back.easeInOut"  
                            data-endspeed="300"><hr class="topline"><h2>Aluminium Based <br> Fire Extinguishers </h2><hr class="bottomline">
                        </div>    
                        
                    </li>
                    
                     <li data-transition="fade" data-slotamount="7" data-masterspeed="1500" >
                        <!-- MAIN IMAGE -->
                        <img src="<?php echo base_url(); ?>assets/demos/slider2.jpeg"  alt="slidebg2"  data-bgfit="cover" data-bgposition="center center" data-bgrepeat="no-repeat">
        				<div class="tp-dottedoverlay twoxtwo"></div>
                        
                        <!-- LAYER NR. 3 -->
                        <div class="tp-caption rev-video skewfromleft customout"
                            data-x="center"
                            data-y="140"
                            data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                            data-speed="800"
                            data-start="1500"
                            data-easing="Power4.easeOut"
                            data-endspeed="300"
                            data-endeasing="Power1.easeIn" 
                            data-captionhidden="on"
                            style="z-index: 6"><hr class="topline"><h2>Our company offers <br>safe, efficient and highest quality <br> Fire Extinguishers.</h2><hr class="bottomline">

                        </div>
                    </li>
					
					<li data-transition="fade" data-slotamount="7" data-masterspeed="1500" >
                        <!-- MAIN IMAGE -->
                        <img src="<?php echo base_url(); ?>assets/demos/slider3.jpeg"  alt="slidebg3"  data-bgfit="cover" data-bgposition="center center" data-bgrepeat="no-repeat">
        				<div class="tp-dottedoverlay twoxtwo"></div>
                        
                        <!-- LAYER NR. 3 -->
                        <div class="tp-caption rev-video skewfromleft customout"
                            data-x="center"
                            data-y="140"
                            data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                            data-speed="800"
                            data-start="1500"
                            data-easing="Power4.easeOut"
                            data-endspeed="300"
                            data-endeasing="Power1.easeIn"
                            data-captionhidden="on"
                            style="z-index: 6"><hr class="topline"><h2>Our newest and advanced equipments <br>with your Branding</h2><hr class="bottomline">
                        </div>
                    </li>
		          </ul>
		          <div class="tp-bannertimer"></div>
            </div>
		</div>
    </section>

